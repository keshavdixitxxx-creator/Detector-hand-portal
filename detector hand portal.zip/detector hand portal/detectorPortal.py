"""
Portal de filtros
-----------------
Make a "frame" with BOTH hands (thumb + index finger of each hand).
The shape between your fingertips becomes a portal with a filter inside.
Bring all the fingertips of one hand together (pinch / fist) to switch filter.
Press Q or ESC to quit.

Install:
    pip install opencv-python mediapipe numpy
Run:
    python detectorPortal.py
"""

import math
import time

import cv2
import mediapipe as mp
import numpy as np

# ---------- MediaPipe setup ----------
mpManos = mp.solutions.hands
manos = mpManos.Hands(
    max_num_hands=2,
    model_complexity=0,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.6,
)

PUNTA_PULGAR, PUNTA_INDICE = 4, 8
PUNTAS = [4, 8, 12, 16, 20]


# ---------- Filters (BGR image in -> BGR image out) ----------
def filtroMorado(img):
    capa = np.zeros_like(img)
    capa[:] = (190, 0, 140)  # purple in BGR
    return cv2.addWeighted(img, 0.35, capa, 0.65, 0)


def filtroGris(img):
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(gris, cv2.COLOR_GRAY2BGR)


def filtroSepia(img):
    kernel = np.array([[0.272, 0.534, 0.131],
                       [0.349, 0.686, 0.168],
                       [0.393, 0.769, 0.189]])
    return np.clip(cv2.transform(img, kernel), 0, 255).astype(np.uint8)


def filtroNeon(img):
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    bordes = cv2.Canny(cv2.GaussianBlur(gris, (5, 5), 0), 60, 140)
    bordes = cv2.dilate(bordes, np.ones((2, 2), np.uint8))
    salida = np.zeros_like(img)
    salida[bordes > 0] = (200, 255, 0)  # teal / cyan-green lines
    return salida


def filtroBoceto(img):
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    invertida = cv2.GaussianBlur(255 - gris, (21, 21), 0)
    boceto = cv2.divide(gris, 255 - invertida, scale=256)  # color dodge
    return cv2.cvtColor(boceto, cv2.COLOR_GRAY2BGR)


def filtroTermico(img):
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.applyColorMap(gris, cv2.COLORMAP_JET)


FILTROS = [filtroMorado, filtroGris, filtroSepia, filtroNeon, filtroBoceto, filtroTermico]


# ---------- Helpers ----------
def landmarksAPuntos(mano, ancho, alto):
    return [(int(p.x * ancho), int(p.y * alto)) for p in mano.landmark]


def tamanoMano(puntos):
    return math.dist(puntos[0], puntos[9])  # wrist -> middle finger base


def todosLosDedosJuntos(puntos):
    """True when all 5 fingertips are bunched together (pinch / fist)."""
    centroX = sum(puntos[i][0] for i in PUNTAS) / 5
    centroY = sum(puntos[i][1] for i in PUNTAS) / 5
    return all(math.dist(puntos[i], (centroX, centroY)) < tamanoMano(puntos) * 0.6
               for i in PUNTAS)


def ordenarEsquinas(cuatroPuntos):
    """Sort 4 points around their center so the polygon never twists."""
    pts = np.array(cuatroPuntos, dtype=np.float32)
    cx, cy = pts.mean(axis=0)
    angulos = np.arctan2(pts[:, 1] - cy, pts[:, 0] - cx)
    return pts[np.argsort(angulos)].astype(np.int32)


def aplicarPortal(frame, esquinas, filtro):
    filtrada = filtro(frame)
    mascara = np.zeros(frame.shape[:2], dtype=np.uint8)
    cv2.fillConvexPoly(mascara, esquinas, 255)
    resultado = frame.copy()
    resultado[mascara == 255] = filtrada[mascara == 255]
    cv2.polylines(resultado, [esquinas], True, (255, 255, 255), 1, cv2.LINE_AA)
    return resultado


# ---------- Main ----------
dispositivoCaptura = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Linux/Mac: cv2.VideoCapture(0)

if not dispositivoCaptura.isOpened():
    print("No se pudo abrir la camara.")
    raise SystemExit

indiceFiltro = 0
ultimoCambio = 0.0
ENFRIAMIENTO = 1.0  # seconds between filter changes

while True:
    lecturaCorrecta, imagen = dispositivoCaptura.read()
    if not lecturaCorrecta or imagen is None:
        print("La camara no entrego ninguna imagen.")
        break

    imagen = cv2.flip(imagen, 1)  # mirror view
    alto, ancho = imagen.shape[:2]

    resultado = manos.process(cv2.cvtColor(imagen, cv2.COLOR_BGR2RGB))

    if resultado.multi_hand_landmarks:
        listaManos = [landmarksAPuntos(m, ancho, alto) for m in resultado.multi_hand_landmarks]
        juntos = [todosLosDedosJuntos(p) for p in listaManos]

        # bunched fingers on any hand -> next filter
        ahora = time.time()
        if any(juntos) and ahora - ultimoCambio > ENFRIAMIENTO:
            indiceFiltro = (indiceFiltro + 1) % len(FILTROS)
            ultimoCambio = ahora

        # two hands framing -> portal between thumb and index tips
        if len(listaManos) == 2 and not any(juntos):
            cuatro = [listaManos[0][PUNTA_PULGAR], listaManos[0][PUNTA_INDICE],
                      listaManos[1][PUNTA_PULGAR], listaManos[1][PUNTA_INDICE]]
            esquinas = ordenarEsquinas(cuatro)
            imagen = aplicarPortal(imagen, esquinas, FILTROS[indiceFiltro])

    cv2.imshow("Portal de filtros", imagen)
    if cv2.waitKey(1) & 0xFF in (27, ord("q")):
        break

dispositivoCaptura.release()
cv2.destroyAllWindows()
